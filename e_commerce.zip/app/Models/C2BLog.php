<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class C2BLog extends Model
{
    protected $fillable = ['content'];
}
