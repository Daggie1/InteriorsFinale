<?php

namespace App\Models\Sellers;

use Illuminate\Database\Eloquent\Model;

class MpesaLogs extends Model
{
    protected $fillable = ['content'];
}
