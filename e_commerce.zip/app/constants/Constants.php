<?php


namespace App\constants;


class Constants
{
const STATUS_ACTIVE='Active';
Const STATUS_SUSPENDED='Suspended';

//transaction constants
    const STATUS_SUCCESS='Success';
    Const STATUS_FAILED='Failed';
    //subscription status
    const SUBSCRIBED='Subscribed';
    Const UNSUBSCRIBED='Unsubscribed';
}
