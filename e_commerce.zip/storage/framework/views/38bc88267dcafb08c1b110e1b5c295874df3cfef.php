<?php $__env->startSection('title'); ?> <?php echo e($pageTitle); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-shopping-bag"></i> <?php echo e($pageTitle); ?></h1>
            <p><?php echo e($subTitle); ?></p>
        </div>
        <a href="<?php echo e(route('seller.shop.create')); ?>" class="btn btn-primary pull-right">New Shop</a>
    </div>
        <div class="row">
            <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shopy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="bs-component">
                    <div class="card mb-3 text-white bg-success">

                        <div class="card-body">
                            <div class="card-title">
                                <h3><span class="fa fa-home text-danger"></span>&nbsp;<?php echo e($shopy->name); ?>   <div class="pull-right h6">
                                        <p><b>Status</b></p>
                                        <div class="toggle-flip">
                                            <label>
                                                <input type="checkbox" checked><span class="flip-indecator " data-toggle-on="Active"
                                                                             data-toggle-off="Suspended"></span>
                                            </label>
                                        </div>
                                    </div></h3>

                                <span class="fa fa-location-arrow"></span>  &nbsp;<?php echo e(\App\Models\Counties::find($shopy->location)->name); ?>

                            </div>

                            <blockquote class="card-blockquote">
                                <p><?php echo e($shopy->description); ?></p>

                            </blockquote>
                            <a href="<?php echo e(route('seller.shop.edit',$shopy->id)); ?>" class="btn btn-warning pull-right"><span class="text-white">Manage &nbsp;</span> <span class="fa fa-chevron-right text-white"></span> </a>
                        </div>
                    </div>
                </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('seller.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e_commerce\resources\views/seller/shop/index.blade.php ENDPATH**/ ?>