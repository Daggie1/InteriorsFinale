<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link type="text/css" href="<?php echo e(asset('frontend/css/bootstrap.css')); ?>}">
</head>
<body >
<div  id="app">
    <h3>Vue Js</h3>

        <example-component>

        </example-component>
</div>

<script type="text/javascript" src="<?php echo e(asset('backend/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\e_commerce\resources\views/vue/databinding.blade.php ENDPATH**/ ?>