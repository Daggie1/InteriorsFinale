<?php $__env->startSection('title', 'Homepage'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- ========================= SECTION MAIN ========================= -->
        <section class="section-main bg padding-top-sm">
            <div class="container">
                <div class="row">
                    <div class="col-md-9">
                        <!-- ================= main slide ================= -->
                        <div class="owl-init slider-main owl-carousel" data-items="1" data-dots="false" data-nav="true">
                            <div class="item-slide">
                                <img src="<?php echo e(asset('frontend/images/banners/slide1.jpg')); ?>">
                            </div>
                            <div class="item-slide rounded">
                                <img src="<?php echo e(asset('frontend/images/banners/slide2.jpg')); ?>">
                            </div>
                            <div class="item-slide rounded">
                                <img src="<?php echo e(asset('frontend/images/banners/slide3.jpg')); ?>">
                            </div>
                        </div>
                        <!-- ============== main slidesow .end // ============= -->
                    </div>
                    <!-- col.// -->
                    <div class="col-md-3">
                        <div class="card mt-2 mb-2">
                            <figure class="itemside">
                                <div class="aside">
                                    <div class="img-wrap img-sm border-right"><img src="<?php echo e(asset('frontend/images/items/3.jpg')); ?>"></div>
                                </div>
                                <figcaption class="p-3">
                                    <h6 class="title"><a href="#">Some name of item goes here nice</a></h6>
                                    <div class="price-wrap">
                                        <span class="price-new b">ksh1280</span>
                                        <del class="price-old text-muted">ksh1980</del>
                                    </div>
                                    <!-- price-wrap.// -->
                                </figcaption>
                            </figure>
                        </div>
                        <!-- card.// -->
                        <div class="card mb-2">
                            <figure class="itemside">
                                <div class="aside">
                                    <div class="img-wrap img-sm border-right"><img src="<?php echo e(asset('frontend/images/items/3.jpg')); ?>"></div>
                                </div>
                                <figcaption class="p-3">
                                    <h6 class="title"><a href="#">Some name of item goes here nice</a></h6>
                                    <div class="price-wrap">
                                        <span class="price-new b">kah1280</span>
                                        <del class="price-old text-muted">ksh1980</del>
                                    </div>
                                    <!-- price-wrap.// -->
                                </figcaption>
                            </figure>
                        </div>
                        <!-- card.// -->
                        <div class="card mb-2">
                            <figure class="itemside">
                                <div class="aside">
                                    <div class="img-wrap img-sm border-right"><img src="<?php echo e(asset('frontend/images/items/3.jpg')); ?>"></div>
                                </div>
                                <figcaption class="p-3">
                                    <h6 class="title"><a href="#">Some name of item goes here nice</a></h6>
                                    <div class="price-wrap">
                                        <span class="price-new b">ksh1280</span>
                                        <del class="price-old text-muted">ksh1980</del>
                                    </div>
                                    <!-- price-wrap.// -->
                                </figcaption>
                            </figure>
                        </div>
                        <!-- card.// -->
                    </div>
                    <!-- col.// -->
                </div>
            </div>
            <!-- container .//  -->
        </section>
        <!-- ========================= SECTION MAIN END// ========================= -->

        <!-- ========================= Blog ========================= -->
        <section class="section-content padding-y-sm bg">
            <div class="container">
                <header class="section-heading heading-line">
                    <h4 class="title-section bg">Featured Categories</h4>
                </header>
                <div class="row">
                    <?php $__currentLoopData = $featured_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card-banner" style="height:250px; background-image: url(<?php echo e(asset('storage/'.$category->image)); ?>);">
                            <article class="overlay overlay-cover d-flex align-items-center justify-content-center">
                                <div class="text-center">
                                    <h5 class="card-title"><?php echo e($category->name); ?></h5>
                                    <a href="<?php echo e(route('category.show', $category->slug)); ?>" class="btn btn-warning btn-sm"> View All </a>
                                </div>
                            </article>
                        </div>
                        <!-- card.// -->
                    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <!-- ========================= Blog .END// ========================= -->

        <section class="section-content padding-y-sm bg">
            <div class="container">

                <header class="section-heading heading-line">
                    <h4 class="title-section bg">FEATURED PRODUCTS</h4>
                </header>
                <div class="row">
                    <?php $__currentLoopData = $featured_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <figure class="card card-product">
                                <?php if($product->images->count() > 0): ?>
                                    <div class="img-wrap padding-y"><img src="<?php echo e(asset('storage/'.$product->images->first()->full)); ?>" alt=""></div>
                                <?php else: ?>
                                    <div class="img-wrap padding-y"><img src="https://via.placeholder.com/176" alt=""></div>
                                <?php endif; ?>
                                <figcaption class="info-wrap">
                                    <h4 class="title"><a href="<?php echo e(route('product.show', $product->slug)); ?>"><?php echo e($product->name); ?></a></h4>
                                </figcaption>
                                <div class="bottom-wrap">
                                    <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="btn btn-sm btn-success float-right">View Details</a>
                                    <?php if($product->sale_price != 0): ?>
                                        <div class="price-wrap h5">
                                            <span class="price"> <?php echo e(config('settings.currency_symbol').$product->sale_price); ?> </span>
                                            <del class="price-old"> <?php echo e(config('settings.currency_symbol').$product->price); ?></del>
                                        </div>
                                    <?php else: ?>
                                        <div class="price-wrap h5">
                                            <span class="price"> <?php echo e(config('settings.currency_symbol').$product->price); ?> </span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </figure>
                        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- col // -->
                </div>
                <!-- row.// -->

            </div>
            <!-- container .//  -->
        </section>
        <!-- ========================= SECTION ITEMS ========================= -->
        <section class="section-request bg padding-y-sm">
            <div class="container">
                <header class="section-heading heading-line">
                    <h4 class="title-section bg text-uppercase">Recently Added</h4>
                </header>
                <div class="row">
                    <?php $__currentLoopData = $recently_added; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <figure class="card card-product">
                                <?php if($product->images->count() > 0): ?>
                                    <div class="img-wrap padding-y"><img src="<?php echo e(asset('storage/'.$product->images->first()->full)); ?>" alt=""></div>
                                <?php else: ?>
                                    <div class="img-wrap padding-y"><img src="https://via.placeholder.com/176" alt=""></div>
                                <?php endif; ?>
                                <figcaption class="info-wrap">
                                    <h4 class="title"><a href="<?php echo e(route('product.show', $product->slug)); ?>"><?php echo e($product->name); ?></a></h4>
                                </figcaption>
                                <div class="bottom-wrap">
                                    <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="btn btn-sm btn-success float-right">View Details</a>
                                    <?php if($product->sale_price != 0): ?>
                                        <div class="price-wrap h5">
                                            <span class="price"> <?php echo e(config('settings.currency_symbol').$product->sale_price); ?> </span>
                                            <del class="price-old"> <?php echo e(config('settings.currency_symbol').$product->price); ?></del>
                                        </div>
                                    <?php else: ?>
                                        <div class="price-wrap h5">
                                            <span class="price"> <?php echo e(config('settings.currency_symbol').$product->price); ?> </span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </figure>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- col // -->
                </div>
                <!-- row.// -->

            </div>
            <!-- container // -->
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ooks\e commerce\web\caleb\resources\views/site/pages/homepage.blade.php ENDPATH**/ ?>