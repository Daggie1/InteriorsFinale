<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css/main.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css/remove_caret_from_number_input.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css/font-awesome/4.7.0/css/font-awesome.min.css')); ?>"/>


    <title>New Account - <?php echo e(config('app.name')); ?></title>
</head>
<body >
<br>
<br>
<br>

<main  id="app">
<div class="">
   <div class="row ">
       <div class="offset-md-4"></div>
       <div class="col-md-5 card mb-3 border-success">

            <form  class="login-form" action="<?php echo e(route('seller.register.post')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                        <section class="text-center"><img class="app-sidebar__user-avatar" width="100" src="<?php echo e(asset('frontend/images/avatars/default_user.jpg')); ?>" alt="User Image">
                        </section>
                        <br>
                        <h3 class="login-head text-center "> Lets Begin Here</h3>
                        <br>
                        <br>
                <div class="row">
                    <div class="col-md-6">
                <div class="form-group">
                    <label class="control-label" for="email">First Name</label>
                    <input class="form-control <?php if ($errors->has('f_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('f_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" id="f_name" name="f_name" placeholder="First name" autofocus value="<?php echo e(old('f_name')); ?>" required>
                   <span class="invalid-feedback"><?php if ($errors->has('f_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('f_name'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?></span>
                </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label" for="email">Last Name</label>
                            <input class="form-control <?php if ($errors->has('l_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('l_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" id="name" name="l_name" placeholder="Last name"  value="<?php echo e(old('l_name')); ?>" required>
                            <span class="invalid-feedback"><?php if ($errors->has('l_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('l_name'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?></span>
                        </div>
                    </div>
                </div>
                        <div class="form-group">
                            <label class="control-label" for="email">Phone</label>
                            <div class="input-group">
                                <div class="input-group-prepend"><span class="input-group-text">254</span></div>
                                <input class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="tel" pattern="2547[0-9]{9}"  id="phone" name="phone" placeholder="07XXX"  value="<?php echo e(old('phone')); ?>" required>
                                <span class="invalid-feedback"><?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?></span>
                            </div>
                        </div>





                                <div class="form-group">
                                    <label class="control-label" for="email">Email</label>
                                    <input class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="email" id="email" name="email" placeholder="Email address"  value="<?php echo e(old('email')); ?>" required>
                                    <span class="invalid-feedback"><?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?></span>
                                </div>

                <div class="form-group">
                    <label class="control-label" for="email">ID No</label>
                    <input class="form-control <?php if ($errors->has('id_no')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id_no'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="number" id="id_no" name="id_no" placeholder="Identification Number"  value="<?php echo e(old('id_no')); ?>" required>
                    <span class="invalid-feedback"><?php if ($errors->has('id_no')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id_no'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?></span>
                </div>

                        <div class="row"><div class="col-md-6">
                <div class="form-group">

                    <label class="control-label" for="email">Password</label>
                    <input class="form-control" type="password" id="password" name="password" placeholder="Password"  required>
                </div>
                            </div>

                    <div class="col-md-6">
                        <div class="form-group">

                            <label class="control-label" for="email">Confirm Password</label>
                            <input class="form-control" type="password" id="password" name="password" placeholder="Password"  required>
                        </div>
                    </div>
                    </div>


                        <div class="form-group form-check">
                            <label class="form-check-label">
                                <input class="form-check-input" type="checkbox">By Registering you abide to some of our  <a href=""><strong>E-shop &nbsp;</strong>terms and conditions</a>
                            </label>
                        </div>
                <div class="form-group btn-container">
                    <button class="btn btn-primary btn-block" type="submit"><i class="fa fa-sign-in fa-lg fa-fw"></i>Save Details</button>
                </div>
                <p class="text-center">
              Aready hava an account?<span class="text-info"> <a href="<?php echo e(route('seller.login')); ?>">Login here</a> </span>
                </p>

            </form>
       </div>
    <div class="offset-md-3"></div>
   </div>

<script src="<?php echo e(asset('backend/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/plugins/pace.min.js')); ?>"></script>

    <section>
    </section>
</div>
</main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\e_commerce\resources\views/seller/auth/register.blade.php ENDPATH**/ ?>