<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-lg-3">
            <div class="widget-small primary coloured-icon">
                <i class="icon fa fa-shopping-bag fa-3x"></i>
                <div class="info">
                    <h4>Products</h4>
                    <p><b><?php echo e($products->count()); ?></b></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="widget-small info coloured-icon">
                <i class="icon fa fa-dollar fa-3x"></i>
                <div class="info">
                    <h4>Transaction</h4>
                    <p><b><?php echo e($transactions); ?></b></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="widget-small warning coloured-icon">
                <i class="icon fa fa-bar-chart fa-3x"></i>
                <div class="info">
                    <h4>Orders</h4>
                    <p><b><?php echo e($orders); ?></b></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="widget-small danger coloured-icon">
                <i class="icon fa fa-bar-chart fa-3x"></i>
                <div class="info">
                    <h4>Stars</h4>
                    <p><b><?php echo e($orders); ?></b></p>
                </div>
            </div>
        </div>
    </div>

       <a href="<?php echo e(route('seller.shop')); ?>" class="btn btn-facebook"></a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('seller.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ooks\e commerce\web\caleb\resources\views/seller/dashboard/index.blade.php ENDPATH**/ ?>