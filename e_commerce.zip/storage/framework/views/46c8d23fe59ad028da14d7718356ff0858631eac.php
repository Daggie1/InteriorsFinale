<?php $__env->startSection('title'); ?> <?php echo e($pageTitle); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-shopping-bag"></i> <?php echo e($pageTitle); ?></h1>
            <p><?php echo e($subTitle); ?></p>
        </div>

    </div>
    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <div class="tile-body">
                    <table class="table table-hover table-bordered" id="sampleTable">
                        <thead>
                        <tr>
                            <th> # </th>

                            <th> MpesaRecepientNo </th>
                            <th class="text-center"> Phone </th>
                            <th class="text-center"> Status </th>
                            <th class="text-center"> Desc</th>
                            <th class="text-center"> Amount </th>
                            <th class="text-center"> On </th>

                            <th style="width:100px; min-width:100px;" class="text-center text-danger"><i class="fa fa-bolt"> </i></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($transaction->id); ?></td>
                                <td><?php echo e($transaction->MpesaReceiptNumber); ?></td>
                                <td class="text-center">

                                    <?php echo e($transaction->phone); ?>

                                </td>
                                <td class="text-center">
                                    <?php if($transaction->ResultCode == 0): ?>
                                        <span class="badge badge-success">Successful</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Failed</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($transaction->ResultDesc); ?></td>
                                
                                <td><?php echo e($transaction->amount); ?></td>

                                <td><?php echo e(\Carbon\Carbon::parse($transaction->transactionDate )->format('dS M Y')); ?></td>
                                <td class="text-center">
                                    <div class="btn-group" role="group" aria-label="Second group">
                                        <a href="<?php echo e(route('admin.products.edit', $transaction->id)); ?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                        <a href="<?php echo e(route('admin.products.edit',$transaction->id)); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e_commerce\resources\views/admin/transactions/bookings.blade.php ENDPATH**/ ?>