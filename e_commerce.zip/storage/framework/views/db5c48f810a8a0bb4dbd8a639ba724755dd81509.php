<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
    <div class="app-sidebar__user">
        <img width="200" height="150" src="<?php echo e(asset('frontend/images/avatars/default_user.jpg')); ?>" alt="User Image">





    </div>

    <ul class="app-menu">
        <li>
            <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'seller.dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('seller.dashboard')); ?>">
                <i class="app-menu__icon fa fa-dashboard"></i>
                <span class="app-menu__label">Dashboard</span>
            </a>
        </li>




















        <li>
            <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'seller.shop' ? 'active' : ''); ?>" href="<?php echo e(route('seller.shop')); ?>">
                <i class="app-menu__icon fa fa-home"></i>
                <span class="app-menu__label">Shops</span>
            </a>
        </li>

    </ul>
</aside>
<?php /**PATH C:\xampp\htdocs\e_commerce\resources\views/seller/partials/sidebar.blade.php ENDPATH**/ ?>